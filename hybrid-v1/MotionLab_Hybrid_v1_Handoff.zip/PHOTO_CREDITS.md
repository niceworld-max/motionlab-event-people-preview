# 혼합 버전 사진 출처

원본 v3와 동일한 네 장이며, 실제 파일은 standalone HTML 안과 integration/assets 안에 포함된다. 아래 로컬 자산명은 원본의 자산 식별명이다.

## 무료 사진 — 실제 사용 네 장
각 사진 상세 페이지에 ‘Unsplash 라이선스하에서 무료로 사용 가능’과 무료 다운로드가 표시되는 것을 확인했다. Unsplash+ 유료 사진은 사용하지 않았다. 아래 해상도는 실제 내려받은 파일을 읽어 확인한 값이다.

| 작가 | 원본 사진 페이지 | 로컬 파일 | 실제 해상도 |
| --- | --- | --- | --- |
| The Climate Reality Project[3] | [Hb6uWq0i4MI](https://unsplash.com/ko/%EC%82%AC%EC%A7%84/selective-focus-photography-of-people-sitting-on-chairs-while-writing-on-notebooks-Hb6uWq0i4MI) | `assets/MotionLab_Photo_01.jpg` | 2560×1707 |
| Headway[4] | [F2KRf_QfCqw](https://unsplash.com/ko/%EC%82%AC%EC%A7%84/%EB%B0%A9-%EC%95%88%EC%9D%98-%EC%9D%98%EC%9E%90%EC%97%90-%EC%95%89%EC%95%84%EC%9E%88%EB%8A%94-%EC%82%AC%EB%9E%8C%EB%93%A4%EC%9D%98-%EA%B5%B0%EC%A4%91-F2KRf_QfCqw) | `assets/MotionLab_Photo_03.jpg` | 2560×1707 |
| Product School[5] | [nOvIa_x_tfo](https://unsplash.com/ko/%EC%82%AC%EC%A7%84/%EA%B1%B4%EB%AC%BC-%EB%A1%9C%EB%B9%84%EC%97%90-%EC%9E%88%EB%8A%94-%EC%82%AC%EB%9E%8C%EB%93%A4%EC%9D%98-%EA%B5%B0%EC%A4%91-nOvIa_x_tfo) | `assets/MotionLab_Photo_04.jpg` | 2560×1707 |
| Alexandre Pellaes[6] | [6vAjp0pscX0](https://unsplash.com/ko/%EC%82%AC%EC%A7%84/%EB%AC%B4%EB%8C%80%EC%97%90%EC%84%9C-%EB%A7%8E%EC%9D%80-%EC%B2%AD%EC%A4%91%EC%9D%84-%ED%96%A5%ED%95%B4-%EC%97%B0%EC%84%A4%ED%95%98%EB%8A%94-%EC%97%B0%EC%84%A4%EC%9E%90-6vAjp0pscX0) | `assets/MotionLab_Photo_05.jpg` | 2560×1707 |

- 이용 조건: Unsplash License는 무료 다운로드·수정·사용을 상업적·비상업적 용도로 허용하고, 필수는 아니지만 작가 표기를 권장한다고 설명한다. 수정 없는 이미지 판매, 경쟁 이미지 서비스 구축 등에는 제한이 있다.[1]
- **저작권 소멸·CC0이라고 표현하지 않는다.** 사진 저작권은 작가에게 있으며 무료 라이선스 범위에서 활용한다.
- 인물·상표·장소 등에 관한 추가 권한이나 해당 인물의 회사 추천·고객 관계를 확인한 것은 아니다. 실제 시공지 행사 사진·고객사·고객 추천으로 소개하지 않는다. 외부 공개 전 사용 맥락과 추가 권리를 검토한다.
- 영상과 미리보기에는 스톡 사진·예시 서비스 UI임을 표시했다. 실제 고객사 화면·실적 숫자·논문·개인정보는 넣지 않았다.
- 이미지 처리: 크롭·크기 조정·둥근 모서리·하단 그라데이션 캡션·3D 변형·심도 처리를 적용했다.

## Sources

[1] https://unsplash.com/license
[2] https://prompt-motion.com/twoclipping-d89be5
[3] https://unsplash.com/ko/%EC%82%AC%EC%A7%84/selective-focus-photography-of-people-sitting-on-chairs-while-writing-on-notebooks-Hb6uWq0i4MI
[4] https://unsplash.com/ko/%EC%82%AC%EC%A7%84/%EB%B0%A9-%EC%95%88%EC%9D%98-%EC%9D%98%EC%9E%90%EC%97%90-%EC%95%89%EC%95%84%EC%9E%88%EB%8A%94-%EC%82%AC%EB%9E%8C%EB%93%A4%EC%9D%98-%EA%B5%B0%EC%A4%91-F2KRf_QfCqw
[5] https://unsplash.com/ko/%EC%82%AC%EC%A7%84/%EA%B1%B4%EB%AC%BC-%EB%A1%9C%EB%B9%84%EC%97%90-%EC%9E%88%EB%8A%94-%EC%82%AC%EB%9E%8C%EB%93%A4%EC%9D%98-%EA%B5%B0%EC%A4%91-nOvIa_x_tfo
[6] https://unsplash.com/ko/%EC%82%AC%EC%A7%84/%EB%AC%B4%EB%8C%80%EC%97%90%EC%84%9C-%EB%A7%8E%EC%9D%80-%EC%B2%AD%EC%A4%91%EC%9D%84-%ED%96%A5%ED%95%B4-%EC%97%B0%EC%84%A4%ED%95%98%EB%8A%94-%EC%97%B0%EC%84%A4%EC%9E%90-6vAjp0pscX0
